import pygame

pygame.init()   

screen_width = 800
screen_height = 600

screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()

background = pygame.image.load('C:\\python\\workspace\\backim.jpg')

character = pygame.image.load('C:\\python\\workspace\\character.gif')
charsize = character.get_rect().size
character_width = charsize[0]
character_height = charsize[1]
charxpos = (screen_width / 2) - (character_width / 2)
charypos = screen_height - character_height
mx = 0
my = 0
charspeed = 3/5
pygame.display.set_caption("jojo's bizzard program")

running = True
while running:
    dt = clock.tick(120)

    print("fps : " + str(clock.get_fps()))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
                mx -= charspeed
            elif event.key == pygame.K_d:
                mx += charspeed
            elif event.key == pygame.K_w:
                my -= charspeed
            elif event.key == pygame.K_s:
                my += charspeed
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_a or pygame.K_d:
                mx = 0
            if event.key == pygame.K_w or pygame.K_s:
                my = 0
    
    charxpos += mx * dt
    charypos += my * dt

    if charxpos < 0:
        charxpos = 0
    if charxpos > screen_width - character_width:
        charxpos =  screen_width - character_width
    if charypos < 0:
        charypos = 0
    if charypos > screen_height - character_height - 45:
        charypos =  screen_height - character_height - 45

    screen.blit(background, (0,0))
    screen.blit(character, (charxpos,charypos))

    pygame.display.update()